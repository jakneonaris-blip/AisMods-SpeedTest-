# AisMods SpeedTest — starter project

Proyek Android native Kotlin + Jetpack Compose. Versi awal ini menyediakan:
- Live speed dari Google Fused Location Provider (data lokasi nyata perangkat)
- Permintaan lokasi high accuracy dengan interval target 200 ms dan minimum 100 ms
- Tampilan Speedometer, Timer, GPS Monitor, dan Settings
- Pilihan jarak 201 m, 402 m, 501 m, serta custom
- Pilihan warna aksen
- Workflow GitHub Actions untuk membangun APK debug tanpa Android Studio

## Cara membuat APK hanya dengan HP Android
1. Buat akun / masuk ke GitHub melalui browser.
2. Buat repository baru bernama `AisModsSpeedTest`.
3. Unggah seluruh isi folder proyek ini ke repository (jangan unggah folder ZIP sebagai satu file; ekstrak dulu).
4. Buka tab **Actions**, pilih **Build AisMods SpeedTest APK**, lalu tekan **Run workflow**.
5. Setelah proses selesai, buka hasil workflow dan unduh artifact `AisMods-SpeedTest-debug`.
6. Ekstrak artifact, lalu pasang `app-debug.apk` di HP. Android mungkin meminta izin instalasi dari sumber tersebut.

## Catatan penting
- APK debug belum ditandatangani untuk distribusi publik; untuk rilis final perlu konfigurasi signing key.
- Interval 100–200 ms adalah permintaan ke Android, bukan jaminan. Perangkat, chipset GNSS, kondisi langit, penghemat baterai, dan kebijakan Android menentukan frekuensi aktual.
- Fused Location Provider tidak menyediakan hitungan satelit GNSS. Integrasi `GnssStatus` native akan ditambahkan pada iterasi berikutnya.
- Drag/lap pada starter ini masih kerangka UI; pemicu start/finish, pencatatan jarak, penyimpanan sesi, dan algoritme pengukuran harus dilengkapi serta diuji di kendaraan sebelum dipakai untuk pengukuran performa.
- Aplikasi tidak menghapus batasan trial aplikasi lain atau memakai layanan/lisensi pihak ketiga. Ini adalah aplikasi mandiri.
