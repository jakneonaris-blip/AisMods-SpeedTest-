package com.aismods.speedtest

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111827)
private val Cyan = Color(0xFF00DDF5)
private val Muted = Color(0xFF9AA7BC)

class MainActivity : ComponentActivity() {
    private lateinit var fused: FusedLocationProviderClient
    private var locationCallback: LocationCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fused = LocationServices.getFusedLocationProviderClient(this)
        setContent {
            var hasPermission by remember { mutableStateOf(hasLocationPermission()) }
            val locationPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { grants ->
                hasPermission = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            }
            var speedKmh by remember { mutableFloatStateOf(0f) }
            var accuracy by remember { mutableFloatStateOf(0f) }
            var latitude by remember { mutableDoubleStateOf(0.0) }
            var longitude by remember { mutableDoubleStateOf(0.0) }
            var gpsAge by remember { mutableLongStateOf(0L) }
            var selectedTab by remember { mutableStateOf("Speedometer") }
            var distanceTarget by remember { mutableIntStateOf(201) }
            var customDistance by remember { mutableStateOf("300") }
            var running by remember { mutableStateOf(false) }
            var elapsed by remember { mutableLongStateOf(0L) }
            var traveledMeters by remember { mutableFloatStateOf(0f) }
            var topSpeed by remember { mutableFloatStateOf(0f) }
            var accent by remember { mutableStateOf(Cyan) }

            DisposableEffect(Unit) {
                onDispose { stopGps() }
            }

            LaunchedEffect(hasPermission) {
                if (hasPermission) {
                    startGps { loc ->
                        val raw = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
                        // Light smoothing for display only; raw GPS values remain device-derived.
                        speedKmh = if (raw < 1.0f) 0f else (speedKmh * 0.35f + raw * 0.65f)
                        accuracy = loc.accuracy
                        latitude = loc.latitude
                        longitude = loc.longitude
                        gpsAge = (System.currentTimeMillis() - loc.time).coerceAtLeast(0L)
                        if (running) {
                            topSpeed = max(topSpeed, speedKmh)
                        }
                    }
                }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = accent,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                Scaffold(
                    containerColor = Bg,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0D1220)) {
                            listOf("Speedometer", "Timer", "GPS", "Settings").forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(
                                            when (tab) {
                                                "Speedometer" -> Icons.Default.Speed
                                                "Timer" -> Icons.Default.Timer
                                                "GPS" -> Icons.Default.MyLocation
                                                else -> Icons.Default.Palette
                                            }, contentDescription = tab
                                        )
                                    },
                                    label = { Text(tab) }
                                )
                            }
                        }
                    }
                ) { padding ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding)
                            .background(Bg).padding(horizontal = 18.dp),
                        contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text("AISMODS", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("SpeedTest", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                            Text("GPS speed • Drag meter • Lap timer", color = Muted, fontSize = 13.sp)
                        }
                        when (selectedTab) {
                            "Speedometer" -> {
                                item {
                                    CardBlock {
                                        Text("LIVE SPEED", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(String.format(Locale.US, "%.1f", speedKmh), color = accent,
                                            fontSize = 76.sp, fontWeight = FontWeight.Black)
                                        Text("km/h", color = Color.White, fontSize = 20.sp)
                                        Spacer(Modifier.height(8.dp))
                                        LinearProgressIndicator(
                                            progress = { (speedKmh / 240f).coerceIn(0f, 1f) },
                                            modifier = Modifier.fillMaxWidth(), color = accent,
                                            trackColor = Color(0xFF293449)
                                        )
                                        Text(if (hasPermission) "GPS aktif • usia data ${gpsAge} ms" else "Izin lokasi diperlukan",
                                            color = Muted, fontSize = 12.sp)
                                    }
                                }
                                item {
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        MetricCard("AKURASI", if (accuracy > 0) "±${accuracy.toInt()} m" else "--", Modifier.weight(1f))
                                        MetricCard("TOP SPEED", String.format(Locale.US, "%.1f", topSpeed), Modifier.weight(1f))
                                    }
                                }
                                item {
                                    Button(
                                        onClick = {
                                            if (!hasPermission) locationPermissionLauncher.launch(arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            ))
                                            else { running = !running; if (!running) { elapsed = 0; traveledMeters = 0f; topSpeed = 0f } }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = accent)
                                    ) { Text(if (!hasPermission) "Aktifkan GPS" else if (running) "STOP SESI" else "MULAI REKAM", color = Bg) }
                                }
                            }
                            "Timer" -> {
                                item {
                                    CardBlock {
                                        Text("DRAG METER & LAP TIMER", color = Muted, fontWeight = FontWeight.Bold)
                                        Text("Pilih jarak", color = Color.White)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf(201, 402, 501).forEach { d ->
                                                FilterChip(selected = distanceTarget == d, onClick = { distanceTarget = d },
                                                    label = { Text("${d} m") })
                                            }
                                        }
                                        OutlinedTextField(value = customDistance, onValueChange = {
                                            customDistance = it.filter(Char::isDigit)
                                            customDistance.toIntOrNull()?.let { n -> if (n > 0) distanceTarget = n }
                                        }, label = { Text("Jarak custom (meter)") }, singleLine = true)
                                        Text("Target: $distanceTarget meter", color = accent, fontWeight = FontWeight.Bold)
                                        Text("Kecepatan GPS: ${String.format(Locale.US, "%.1f", speedKmh)} km/h", color = Muted)
                                        Button(onClick = { running = !running }, modifier = Modifier.fillMaxWidth()) {
                                            Text(if (running) "Akhiri sesi" else "Mulai sesi")
                                        }
                                        Text("Pengukuran jarak otomatis dan pemicu start/finish berbasis GPS akan disempurnakan pada tahap berikutnya.",
                                            color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            "GPS" -> {
                                item {
                                    CardBlock {
                                        Text("GPS LIVE MONITOR", color = accent, fontWeight = FontWeight.Bold)
                                        InfoLine("Status", if (hasPermission) "Izin diberikan" else "Belum diizinkan")
                                        InfoLine("Akurasi", if (accuracy > 0) "±${"%.1f".format(accuracy)} meter" else "--")
                                        InfoLine("Latitude", if (latitude != 0.0) latitude.toString() else "--")
                                        InfoLine("Longitude", if (longitude != 0.0) longitude.toString() else "--")
                                        InfoLine("Usia data", "$gpsAge ms")
                                        InfoLine("Kecepatan", "${"%.1f".format(speedKmh)} km/h")
                                        Text("Jumlah satelit GNSS tidak dilaporkan oleh fused location API; akan ditambahkan melalui GnssStatus Android pada iterasi berikutnya.",
                                            color = Muted, fontSize = 12.sp)
                                        Button(onClick = {
                                            locationPermissionLauncher.launch(arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            ))
                                        }, modifier = Modifier.fillMaxWidth()) {
                                            Text("Periksa izin lokasi")
                                        }
                                    }
                                }
                            }
                            else -> {
                                item {
                                    CardBlock {
                                        Text("TAMPILAN & KUSTOMISASI", color = accent, fontWeight = FontWeight.Bold)
                                        Text("Warna aksen", color = Color.White)
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            listOf(Cyan, Color(0xFF2979FF), Color(0xFF00E676), Color(0xFFFF1744), Color(0xFFFF9100), Color.White).forEach { c ->
                                                Box(Modifier.size(34.dp).background(c, RoundedCornerShape(50)).clickable { accent = c })
                                            }
                                        }
                                        Text("Wallpaper foto pribadi dan pilihan desain analog/digital akan ditambahkan pada iterasi UI berikutnya.",
                                            color = Muted, fontSize = 12.sp)
                                        InfoLine("Refresh UI", "Mengikuti refresh layar perangkat")
                                        InfoLine("GPS request", "High accuracy • interval adaptif")
                                        InfoLine("Trial", "Tidak ada")
                                    }
                                }
                            }
                        }
                        item {
                            Text("Catatan akurasi: aplikasi menampilkan data yang diberikan perangkat. Frekuensi 5–10 Hz dan refresh 120 Hz adalah target bersyarat, bukan jaminan pada semua HP.",
                                color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startGps(onLocation: (Location) -> Unit = {}) {
        if (!hasLocationPermission()) return
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 200L)
            .setMinUpdateIntervalMillis(100L)
            .setMaxUpdateDelayMillis(250L)
            .setWaitForAccurateLocation(false)
            .build()
        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let(onLocation)
            }
        }
        locationCallback = callback
        try {
            fused.requestLocationUpdates(request, callback, mainLooper)
        } catch (_: SecurityException) { }
    }

    private fun stopGps() {
        locationCallback?.let { fused.removeLocationUpdates(it) }
        locationCallback = null
    }
}

@Composable
private fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted)
        Text(value, color = Color.White, fontWeight = FontWeight.Medium)
    }
}
